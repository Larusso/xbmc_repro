skin.maximinimalismMKII
===================

Maximinimalism Mark II is a skin for XBMC 13 (Gotham) and above.
It`s a fork from [Maximinimalism](https://github.com/chrisbevan/skin.maximinimalism) 

The Mark II has a few changes regarding fanart usage and the main menu.

- This version is for XBMC video users only. I removed the menu points for music and photo (because this skin is planned for my use only).

- The fanart background will change in movie and tv show lists too.

- The recent items view will only display recent tv episodes.  

Larusso.

  